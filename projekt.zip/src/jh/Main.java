package jh;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(); //1 kc
        int b = sc.nextInt(); //2 kc
        int c = sc.nextInt(); //5 kc
        int d = sc.nextInt(); //10 kc
        int e = sc.nextInt(); //20 kc
        int f = sc.nextInt(); //50 kc
        int g = sc.nextInt(); //cena polozky

        a = a*1;
        b = b*2;
        c = c*5;
        d = d*10;
        e = e*20;
        f = f*50;

        if (g<=a+b+c+d+e+f){
            System.out.println("mas dostatecny financni obnos");
            System.out.print("zbyde ti: ");
            System.out.print(a+b+c+d+e+f - g);
            System.out.print(" Kč");
        }else{
            System.out.println("nemas dostatecny financni obnos");
        }

}
}
